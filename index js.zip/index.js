function chk(value) {
  var tmp = document.getElementById("point").innerHTML;
  tmp = Number(tmp);
  tmp += value;
  document.getElementById("point").innerHTML=tmp;


}


$('.cell').click(function() 
{
      var type = $(this).attr('id').substr(0,3);
      var id = Number($(this).attr('id').substr(4,3));
        //alert($(this).attr('class'));
      var nxt = 
      alert(id);
      alert(type);

      alert(id.toString(16));
           if ( $( this ).hasClass( "chked" ) ) 
           {
                document.getElementById(type+);
                $( this ).removeClass( "chked" );
            } 
            else
            {
                $( this ).addClass( "chked" );
            } 
    }
);