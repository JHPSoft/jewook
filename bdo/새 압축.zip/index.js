$(".cell").click(function () {
   $(this).toggleClass("chked");
});
